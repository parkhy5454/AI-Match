import { NextResponse, NextRequest } from 'next/server';
import { requireUser } from '@/lib/auth';
import prisma from '@/lib/db';

/**
 * 프로필 공개 설정 관리
 * POST /api/profile/visibility (변경)
 * GET /api/profile/visibility (조회)
 */
export async function POST(req: NextRequest) {
  try {
    const user = await requireUser(req);

    let body;
    try {
      body = await req.json();
    } catch (error) {
      return NextResponse.json(
        { success: false, error: '요청 형식이 올바르지 않습니다' },
        { status: 400 }
      );
    }

    const { isPrivate } = body;

    if (typeof isPrivate !== 'boolean') {
      return NextResponse.json(
        { success: false, error: '공개 설정 값이 필요합니다 (true/false)' },
        { status: 400 }
      );
    }

    // 프로필 공개 설정 업데이트
    const updated = await prisma.user.update({
      where: { id: user.id },
      data: {
        isPrivate,
      },
      select: {
        id: true,
        isPrivate: true,
        email: true,
      },
    });

    const status = isPrivate ? '비공개' : '공개';
    console.log('[Profile Visibility] 변경:', user.id, '상태:', status);

    return NextResponse.json({
      success: true,
      message: `프로필이 ${status}로 설정되었습니다`,
      data: {
        isPrivate: updated.isPrivate,
        visibility: isPrivate ? 'private' : 'public',
      },
    });
  } catch (error) {
    console.error('[Profile Visibility] 에러:', error);
    return NextResponse.json(
      { success: false, error: '프로필 설정 변경 중 오류가 발생했습니다' },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser(req);

    const currentUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        isPrivate: true,
        email: true,
      },
    });

    if (!currentUser) {
      return NextResponse.json(
        { success: false, error: '사용자를 찾을 수 없습니다' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: {
        isPrivate: currentUser.isPrivate,
        visibility: currentUser.isPrivate ? 'private' : 'public',
        description: currentUser.isPrivate
          ? '비공개: 검색 결과에 나타나지 않습니다'
          : '공개: 다른 사용자가 검색할 수 있습니다',
      },
    });
  } catch (error) {
    console.error('[Profile Visibility GET] 에러:', error);
    return NextResponse.json(
      { success: false, error: '프로필 설정 조회 중 오류가 발생했습니다' },
      { status: 500 }
    );
  }
}
